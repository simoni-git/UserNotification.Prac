//
//  UserNotifications_PracTests.swift
//  UserNotifications.PracTests
//
//  Created by 시모니 on 2/7/25.
//

import Testing
@testable import UserNotifications_Prac

struct UserNotifications_PracTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
