//
//  메모장.swift
//  UserNotifications.Prac
//
//  Created by 시모니 on 2/7/25.
//

import Foundation

/*
 - 권한 허용의 알림은 앱 최초 실행시 나타나게되며, 한번 허용하거나 불허용하면 그 값이 유지된다.
 
 
 */
